const CACHE = "mi-dia-v1";
const FILES = ["/", "/index.html", "/manifest.json", "/icon.svg", "/config.js"];

self.addEventListener("install", e =>
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES)))
);

self.addEventListener("fetch", e =>
  e.respondWith(
    caches.match(e.request).then(cached => cached || fetch(e.request))
  )
);

self.addEventListener("activate", e =>
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    )
  )
);
